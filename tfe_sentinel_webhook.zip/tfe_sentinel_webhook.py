import json
import http.client
import os

def run(event, context):
    commits = event['commits']
    policies = []
    for x in event['commits']:
        for y in x['added']:
            if json.dumps(y, indent=2).strip('"').endswith('.sentinel'):
                policies.append(y)
            elif json.dumps(y, indent=2).strip('"').endswith('.json'):
                file = download(json.dumps(y, indent=2).strip('"'))
                filejson = json.loads(file)
                policyname = json.dumps(filejson['data']['attributes']['name'], indent=2).strip('"')
                if not resolve(policyname) == "false":
                    raise ValueError("policy name already exists")
                else:
                    create(file)
        for y in x['modified']:
            if json.dumps(y, indent=2).strip('"').endswith('.sentinel'):
                policies.append(y)
            elif json.dumps(y, indent=2).strip('"').endswith('.json'):
                file = download(json.dumps(y, indent=2).strip('"'))
                filejson = json.loads(file)
                policyname = json.dumps(filejson['data']['attributes']['name'], indent=2).strip('"')
                policyid = resolve(policyname)
                if not policyid == "false":
                    update(file, policyid)
                else:
                    print("Updated policy name doesn't exist, creating")
                    create(file)
        for y in x['removed']:
            if json.dumps(y, indent=2).strip('"').endswith(('.json','.sentinel')):
                raise ValueError("This lambda does not yet support deleting policies")
    for z in policies:
        policyid = resolvebypath(z)
        if not policyid == "false":
            attach(z, policyid)
        else:
            raise ValueError("Sentinel policy " + z + " is not in use")
    return {
    "statusCode": 200,
    "headers": { :Content-Type": "application/json" },
    "body": json.dumps({ 'username': 'bob', 'id': 20 })
    }
    
def download(file):
    host = os.environ['vcsrawhost']
    path = os.environ['vcsrawpath']
    conn = http.client.HTTPSConnection(host)
    conn.request("GET", path + file)
    r1 = conn.getresponse()
    return(r1.read())

def resolve(name):
    host = os.environ['tfehost']
    path = "/api/v2/organizations/" + os.environ['tfeorg'] + "/policies"
    headers = {
        "Authorization": "Bearer " + os.environ['tfeteamtoken']
    }
    conn = http.client.HTTPSConnection(host)
    conn.request("GET", path, "", headers)
    r1 = conn.getresponse()
    r2 = json.loads(r1.read())
    for x in r2['data']:
        if json.dumps(x['attributes']['name'], indent=2).strip('"') == name:
            return json.dumps(x['id'], indent=2).strip('"')
    return("false")
    
def resolvebypath(policy):
    host = os.environ['tfehost']
    path = "/api/v2/organizations/" + os.environ['tfeorg'] + "/policies"
    headers = {
        "Authorization": "Bearer " + os.environ['tfeteamtoken']
    }
    conn = http.client.HTTPSConnection(host)
    conn.request("GET", path, "", headers)
    r1 = conn.getresponse()
    r2 = json.loads(r1.read())
    for x in r2['data']:
        if x['attributes']['enforce']:
            if json.dumps(x['attributes']['enforce'][0]['path'], indent=2).strip('"') == policy:
                return json.dumps(x['id'], indent=2).strip('"')
    return("false")
    
def attach(policy, policyid):
    host = os.environ['tfehost']
    path = ("/api/v2/policies/" + policyid + "/upload")
    file = download(policy.strip('"'))
    headers = {
        "Authorization": "Bearer " + os.environ['tfeteamtoken'],
        "Content-Type": "application/octet-stream"
    }
    conn = http.client.HTTPSConnection(host)
    conn.request("PUT", path, file, headers)
    r1 = conn.getresponse()

def update(file, policyid):
    host = os.environ['tfehost']
    path = ("/api/v2/policies/" + policyid)
    headers = {
        "Authorization": "Bearer " + os.environ['tfeteamtoken'],
        "Content-Type": "application/vnd.api+json"
    }
    conn = http.client.HTTPSConnection(host)
    conn.request("PATCH", path, file, headers)
    r1 = conn.getresponse()
    filejson = json.loads(file)
    if filejson['data']['attributes']['enforce']:
        policy = json.dumps(filejson['data']['attributes']['enforce'][0]['path'])
        attach(policy, policyid)
    
def create(file):
    host = os.environ['tfehost']
    path = "/api/v2/organizations/" + os.environ['tfeorg'] + "/policies"
    headers = {
        "Authorization": "Bearer " + os.environ['tfeteamtoken'],
        "Content-Type": "application/vnd.api+json"
    }
    conn = http.client.HTTPSConnection(host)
    conn.request("POST", path, file, headers)
    r1 = conn.getresponse()
    filejson = json.loads(file)
    if filejson['data']['attributes']['enforce']:
        policyname = json.dumps(filejson['data']['attributes']['name'], indent=2).strip('"')
        policyid = resolve(policyname)
        policy = json.dumps(filejson['data']['attributes']['enforce'][0]['path'])
        attach(policy, policyid)